# Sample hydration free energy calculation for cyclopentanol in water

## Data: Léa El Khoury

## About the calculations

These calculations were done for comparison with cyclopentanol in alpha-cyclodextrin, provided in sample data within `OpenMM/sample_files/host-guest-data` within this repository.

### Manifest:
This folder contains:
- `hydration.yaml`:   Yaml script for the first 1000 iterations (1ns).
- `hydration_resume.yaml`: Yank script to resume the simulations; same options except no minimization (`minimize: no`) and resume (`resume_setup: yes`) as well as `resume_setup: yes`, `resume_simulation: yes`, `setup_dir: setup`, `experiments_dir: experiments`
- `input`: Simulation inputs; cyclopentanol was taken from `github.com/MobleyLab/benchmarksets/input_files/cd-set1/mol2/guest-4.mol2` but the residue number was changed from 7 to 1.
- `hydration-out`: Output files from 1000 iterations (1 ns), as well as analysis jupyter notebook, etc.

### Analysis

To analyze, go to `hydration-out` and:
- `yank analyze report --store=experiments --output=hydration_1ns.ipynb`
- Execute the notebook and evaluate the cells
- For the record, a copy of the executed notebook is stored in html at [`hydration_1ns.html`](hydration-out/hydration_1ns.html)

Trajectory extraction can be done by commands like `yank analyze extract-trajectory --netcdf=solvent1.nc --trajectory=complex.pdb --state=0`, for example.
